# RFC-PROTOCOL: The IDRM Normative Contract

| Field | Value |
|-------|-------|
| RFC | RFC-PROTOCOL |
| Track | A (normative) — **the core contract** (the IDRM analog of RFC 2328) |
| Status | REVIEW |
| Requires | RFC-ARCH (context) |
| Supersedes | the former RFC-VOCAB, RFC-AUTHZ, RFC-LIFECYCLE, RFC-API, RFC-GEO, RFC-REALTIME (now §1–§6) |
| Source docs | `dbmodels/enums.py`, `services/service_service.py`, `core/security.py`, `services/{geo,notification,analytics,auth}_service.py`, `api/v1/*.py`, `main.py`, `IDRM-FS.md` §3.3/§6.1, the gateway middleware/routes |
| Created / Updated | 2026-06-30 |

## Abstract

This is the single **normative contract** for IDRM — the analog of John Moy's RFC 2328 (the OSPF protocol
spec). It defines everything an implementer or integrator MUST honour, in six sections: **§1 Vocabulary**
(the controlling enumerations), **§2 Authorization** (roles + the permission matrix), **§3 Lifecycle** (the
service-request state machine — the core "protocol"), **§4 API** (transport, tokens, endpoints, errors),
**§5 Geo** (the geospatial contract), and **§6 Real-time** (WebSocket + notifications). Every claim is matched
to the as-built code; where a feeder doc disagrees with `src/`, **the code governs** and the discrepancy is
logged in RFC-CLARIFY.

## 0. Introduction

**Scope.** The complete behavioural contract of the IDRM MVP.
**Audience.** Every implementer (backend, gateway, all frontends), integrators, and reviewers/QA.
**Non-goals.** *Why* it is shaped this way (RFC-ARCH); what is *observable/tunable* (RFC-MGMT); *how the code
is laid out and run* (RFC-IMPL).
**Normative language.** RFC-2119 keywords (**MUST/SHOULD/MAY**) are used in their precise sense (README
§Conventions). **Scope tags** `[MVP]` / `[FFP]` / `[MVP→FFP]` mark each clause's maturity.

---

## §1. Vocabulary & Normative Enumerations `[MVP]`

The controlling vocabulary. Every fixed-choice value in IDRM is defined **once, here**; all code, SQL, and the
other RFC sections MUST use these exact spellings. Transcribed from `dbmodels/enums.py`, kept in lock-step with
the `CHECK` constraints in `database/init/02-schema.sql`.

### §1.1 Conventions

1. **UPPERCASE, exact spelling** — values are sent/stored as the exact UPPERCASE strings below; the DB `CHECK`
   constraints reject anything else (`"medical"` ✗, `"MEDICAL"` ✓).
2. **`str`-enums** — Python members are `str, Enum`, so `ServiceType.MEDICAL == "MEDICAL"` everywhere.
3. **Three documented exceptions to UPPERCASE** (do not "fix"): **languages** are lowercase ISO-639-1
   (`en/hi/te`); **audit resource types** are **CamelCase** (mirror ORM names); **WebSocket event tokens** are
   lowercase snake wire-strings (`request_created`).
4. **Append-mostly** — adding a value is routine; renaming/removing one is breaking and MUST change `enums.py`
   **and** `02-schema.sql` together.

### §1.2 Master enumeration table (the single source other sections cite)

| Group | Enum (code) | Values | Case | Scope |
|-------|-------------|--------|------|-------|
| Roles | `UserRole` | CITIZEN, VOLUNTEER, ORGANIZER, PROVIDER, MANAGER, EVENT_MANAGER, EXECUTIVE, DM_AUTHORITY, AUDITOR, ADMIN (+ non-account **Public**) | UPPER | MVP (EXECUTIVE FFP) |
| — self-register | `SELF_REGISTRABLE_ROLES` | CITIZEN, PROVIDER, VOLUNTEER | UPPER | MVP |
| Service types | `ServiceType` | RESCUE, MEDICAL, FOOD, SHELTER, WATER, OTHER | UPPER | MVP |
| Priority | `Priority` | CRITICAL, HIGH, MEDIUM, LOW | UPPER | MVP |
| — emergency | `EMERGENCY_PRIORITIES` | CRITICAL, HIGH | UPPER | MVP |
| Statuses | `ServiceStatus` | SUBMITTED, APPROVED, ACCEPTED, IN_PROGRESS, COMPLETED, VERIFIED, REJECTED, CANCELLED, EXPIRED, DISPUTED | UPPER | MVP |
| Privacy | `PrivacyLevel` | PUBLIC, PROTECTED, PRIVATE | UPPER | MVP |
| Org types | `OrgType` | NGO, HOSPITAL, GOVT_AGENCY, VOLUNTEER_GROUP | UPPER | MVP |
| Languages | `Language` | en, hi, te | lower | MVP (12+ FFP) |
| Notif. type | `NotificationType` | SERVICE_CREATED, SERVICE_ACCEPTED, SERVICE_COMPLETED, VERIFICATION_REQUEST, GENERAL, SYSTEM | UPPER | MVP |
| Notif. channel | `NotificationChannel` | EMAIL, SMS, PUSH, IN_APP | UPPER | MVP |
| Notif. status | `NotificationStatus` | PENDING, SENT, FAILED, READ | UPPER | MVP |
| Audit resource | `AuditResourceType` | User, ServiceRequest, Organization, Notification, System | Camel | MVP |
| WS events | (wire) | request_created, request_updated, request_deleted | lower_snake | MVP |

Notes: `OTHER` service type carries a free-text `description`. Map/UI colours (D16): Critical=red, High=orange,
Medium=amber, Low=green. `OrgType`, `NotificationChannel/Status`, CamelCase `AuditResourceType` exist in code
but not in CLAUDE.md's summary (RFC-CLARIFY **C-VOCAB-1**). Status semantics are §3; role authority is §2.

---

## §2. Identity, Roles & Authorization `[MVP]` (EXECUTIVE `[FFP]`)

Source of truth for roles/permissions = **`IDRM-FS.md` §3.3**.

### §2.1 Role taxonomy

The ten `UserRole` values plus a non-account **Public** tier (not logged in, view-only). FS §3.3 column order
(lowest→highest authority): Public · Citizen · Volunteer · Organizer · Provider · Manager · Event Mgr · Exec ·
DM Auth · Auditor · Sys Admin.

- **`DM_AUTHORITY`** ("Event Admin") — the approving authority; MAY be a Government Org **or** a vetted NGO
  (FS BR-ROLE-003). **`EVENT_MANAGER`** runs a disaster-event instance below it. **`AUDITOR`** — `[MVP]`
  read-only (scoring `[FFP]`). **`EXECUTIVE`** — 🔒 `[FFP]`. **`ADMIN`** ("Sys Admin") — full access; grants roles.

### §2.2 Registration vs. granted roles

1. At registration a user MUST pick exactly one **self-registrable** role — `CITIZEN`, `PROVIDER`, or
   `VOLUNTEER` (enforced by `auth_service.register`); new users default to `CITIZEN` (FS BR-ROLE-004).
2. Elevated roles MUST NOT be self-assigned; an `ADMIN` grants them.
3. `POST /users/me` MUST NOT change role or email.
4. **Gap (C-AUTHZ-1):** `POST /users/{id}/role` is specified (CLAUDE.md) but **unimplemented** — only
   `GET|POST /users/me` exist. Role grants are out-of-band until built.

### §2.3 Permission Matrix (normative — FS §3.3)

✅ full · ❌ none · ⚠️ limited (scope) · 🔒 `[FFP]`.

| Permission | Public | Citizen | Volunteer | Organizer | Provider | Manager | Event Mgr | Exec | DM Auth | Auditor | Sys Admin |
|------------|:--:|:--:|:--:|:--:|:--:|:--:|:--:|:--:|:--|:--:|:--:|
| View public map | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | 🔒 | ✅ | ✅ | ✅ |
| Create service request | ❌ | ✅ | ✅ | ✅ | ❌ | ❌ | ❌ | 🔒 | ✅ | ❌ | ✅ |
| View own requests | ❌ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | 🔒 | ✅ | ✅ | ✅ |
| View all requests | ❌ | ❌ | ⚠️ Area | ⚠️ Area | ⚠️ Type | ⚠️ Org | ⚠️ Event | 🔒 | ✅ | ✅ | ✅ |
| Accept service request | ❌ | ❌ | ❌ | ❌ | ✅ | ✅ | ❌ | 🔒 | ❌ | ❌ | ✅ |
| Approve service request † | ❌ | ❌ | ❌ | ❌ | ❌ | ❌ | ❌ | 🔒 | ✅ | ❌ | ✅ |
| Create & manage disaster events | ❌ | ❌ | ❌ | ❌ | ❌ | ❌ | ✅ | 🔒 | ✅ | ❌ | ✅ |
| Allocate funds | 🔒 | 🔒 | 🔒 | 🔒 | 🔒 | 🔒 | 🔒 | 🔒 | 🔒 | 🔒 | 🔒 |
| View financial data | 🔒 | 🔒 | 🔒 | 🔒 | 🔒 | 🔒 | 🔒 | 🔒 | 🔒 | 🔒 | 🔒 |
| Manage users | ❌ | ❌ | ❌ | ⚠️ Team | ⚠️ Org | ⚠️ Org | ⚠️ Event | 🔒 | ⚠️ Jurisdiction | ❌ | ✅ |
| View audit logs | ❌ | ❌ | ❌ | ❌ | ❌ | ❌ | ❌ | 🔒 | ⚠️ Limited | ✅ | ✅ |
| System configuration | ❌ | ❌ | ❌ | ❌ | ❌ | ❌ | ❌ | 🔒 | ❌ | ❌ | ✅ |

**† Approve:** emergency/urgent (`CRITICAL`/`HIGH`) auto-approve (§3.4); DM handles non-urgent + after-the-fact
review. **Finance rows** `[FFP]`. **Disaster events:** the permission exists but there is **no `disaster_event`
entity/endpoint** in code — only the `disaster_types` lookup table (RFC-CLARIFY **C-COV-1**); treat as `[FFP]`.

### §2.4 As-implemented authorization (code governs)

| Action (§3) | Roles allowed in code | Matrix says | Note |
|-------------|-----------------------|-------------|------|
| approve / reject | `{DM_AUTHORITY, ADMIN}` | DM Auth, Sys Admin | matches |
| accept / start / complete | `{PROVIDER, ADMIN}` | Provider **and Manager** | **C-AUTHZ-2:** code omits `MANAGER` |
| verify / cancel / dispute | requestor only (`ADMIN` override) | own request | matches |

### §2.5 Identity & authentication (decision D8)

1. Identity rides a **JWT access token** (15 min); see §4.4. 2. Two trust paths (`get_current_user`):
**via the gateway** (it verifies the JWT and forwards trusted `X-User-ID`/`X-User-Role`, stripping any
client-supplied `X-User-*`), or **direct** `Authorization: Bearer <token>` (Swagger/tests). 3. A user MUST be
`is_active`. 4. Public reads use `get_current_user_optional`: no/invalid creds → anonymous (never a hard 401 on
a public read). 5. **Guest quick-start (D9, deferred):** phone+OTP → lightweight verified `CITIZEN`, pending an
SMS provider.

### §2.6 Privacy-visibility rule

Whether a viewer sees a request's `contact_phone` + `requestor` identity (`_can_see_contact`):
1. `PUBLIC` → everyone (incl. anonymous). 2. else (`PROTECTED` default / `PRIVATE`): only the **requestor**, or
a role in **`{ADMIN, DM_AUTHORITY, MANAGER, EVENT_MANAGER, AUDITOR}`**. 3. Privacy is **raise-only** (D7).
4. **Gap (C12):** "assigned provider gets contact via the system" is **not implemented** — `PROVIDER` is not a
privileged viewer; awaits the user↔org membership model (§3.5).

---

## §3. Service-Request Lifecycle State Machine ⭐ `[MVP]`

The **core protocol** — the analog of OSPF's neighbor FSM. A request *is* an object moving through these
states; matched to `services/service_service.py`.

### §3.1 States

Happy path: `SUBMITTED → APPROVED → ACCEPTED → IN_PROGRESS → COMPLETED → VERIFIED`. Terminal: `VERIFIED`
(success), `REJECTED`, `CANCELLED`, `EXPIRED`. Exception side-state: `DISPUTED`. Terminal states MUST NOT
transition further.

### §3.2 Transition table (matches the code)

Each transition enforces (a) the actor **role** and (b) the current **status** (guard), then sets the new
status + any timestamp. Role failure → **403**; status-guard failure → **409**; missing request → **404**.

| # | Transition | Trigger | Actor | Guard (from) | Effects |
|---|-----------|---------|-------|--------------|---------|
| T0a | → `SUBMITTED` | `POST /services` | requestor | (create) | non-emergency create |
| T0b | → `APPROVED` | `POST /services` | requestor | (create) | **auto-approve** if priority ∈ {CRITICAL, HIGH} (§3.4) |
| T1 | `SUBMITTED`→`APPROVED` | `…/approve` | `{DM_AUTHORITY, ADMIN}` | `SUBMITTED` | visible to providers |
| T2 | `SUBMITTED`\|`DISPUTED`→`REJECTED` | `…/reject` | `{DM_AUTHORITY, ADMIN}` | `SUBMITTED`,`DISPUTED` | sets `rejection_reason` (≥3); terminal |
| T3 | `APPROVED`→`ACCEPTED` | `…/accept` | `{PROVIDER, ADMIN}` | `APPROVED` **&** `provider_id IS NULL` | sets `provider_id`,`accepted_at`; **race-safe** (§3.5); notifies `SERVICE_ACCEPTED` |
| T4 | `ACCEPTED`→`IN_PROGRESS` | `…/start` | `{PROVIDER, ADMIN}` | `ACCEPTED` | work begun |
| T5 | `IN_PROGRESS`→`COMPLETED` | `…/complete` | `{PROVIDER, ADMIN}` | `IN_PROGRESS` | sets `completed_at`; notifies `VERIFICATION_REQUEST` |
| T6 | `COMPLETED`→`VERIFIED` | `…/verify` | requestor (owner; ADMIN) | `COMPLETED` | sets `verified_at`,`rating`(1–5 **required**),`feedback`; terminal |
| T7 | `SUBMITTED`\|`APPROVED`→`CANCELLED` | `…/cancel` | requestor | `SUBMITTED`,`APPROVED` | terminal (FS BR-SR-005) |
| T8 | `IN_PROGRESS`\|`COMPLETED`→`DISPUTED` | `…/dispute` | requestor | `IN_PROGRESS`,`COMPLETED` | raise dispute |
| T9 | `DISPUTED`→`REJECTED` | `…/reject` | `{DM_AUTHORITY, ADMIN}` | `DISPUTED` | DM resolves against requestor |

> `DISPUTED → IN_PROGRESS` (resolve-and-continue) is in the FS but **unbuilt** — only T9 exists (**C-LIFE-1**),
> `[MVP→FFP]`.

**Invariants (MUST):** no state-skipping on the happy path (approval is mandatory — DM or auto); `provider_id`
set exactly at T3 (`NULL` before); `rating` settable only at T6 (DB CHECK); each transition role- **and**
status-guarded.

### §3.3 Auto-approval of emergencies (D5)

On create the system MUST set `APPROVED` (not `SUBMITTED`) when `priority ∈ EMERGENCY_PRIORITIES =
{CRITICAL, HIGH}` (§1.2); else `SUBMITTED`. Auto-approved emergencies skip T1; DM reviews credibility after.

### §3.4 Race-safety of accept

Two providers MUST NOT accept the same request. T3 locks the row `SELECT … FOR UPDATE` constrained to
`status='APPROVED' AND provider_id IS NULL`; the loser gets **409**. The org MUST exist and be `is_verified`
(else 404/403). The org is `AcceptBody.org_id` pending the membership model (§3.5).

### §3.5 Expiry & known gaps

`EXPIRED` is a valid terminal status but **no code path sets it** (no transition, no sweep job) — the trigger
is unspecified/unbuilt (**C9**); treat as reserved `[MVP→FFP]`. The **user↔org membership model** is absent, so
`accept` takes `org_id` in the body and providers don't yet see PROTECTED contact (§2.6 gap).

### §3.6 Request payload (the "packet")

`ServiceCreate` (`POST /services`): `service_type` (§1), `priority` (§1, drives §3.3), `description`
(**10–500** chars), `location` (GeoJSON `[lon,lat]` SRID 4326 — §5.1), `address?`, `num_people_affected`
(**1–1000**, default 1), `privacy_level` (default `PROTECTED`), `contact_phone?` (E.164 `^\+[1-9]\d{1,14}$`).
`ServiceOut` adds `service_id`, `status`, timeline timestamps, `rating`/`feedback`, privacy-gated
`requestor`/`provider` briefs + `contact_phone` (§2.6). **Accepted-but-not-persisted** (audit-only):
`ApproveBody.notes`, `AcceptBody.estimated_arrival`/`notes`, `CancelBody.reason`, `DisputeBody.reason`
(**C-LIFE-2**). `RejectBody.reason` *is* persisted.

### §3.7 Side-effects per transition

After commit, every create/change publishes a best-effort **map event** to Redis `service_requests` —
`request_created` (T0) or `request_updated` (T1–T9) — for WebSocket fan-out (§6). Notifications: T3 →
`SERVICE_ACCEPTED`, T5 → `VERIFICATION_REQUEST` (to the requestor, atomic with the action). DB triggers maintain
`updated_at`, org stats, and the immutable audit log (RFC-MGMT §3) — the service layer MUST NOT duplicate them.

### §3.8 State diagram

```
            ┌──── CRITICAL/HIGH auto-approve (T0b) ────┐
            ▼                                          │
 create─▶ SUBMITTED ─approve(T1)─▶ APPROVED ─accept(T3)─▶ ACCEPTED ─start(T4)─▶ IN_PROGRESS
            │ │                       │                                            │  │
         cancel(T7)              cancel(T7)                                   complete(T5)
            ▼ └──reject(T2)──▶ REJECTED ◀──reject(T9)── DISPUTED ◀──dispute(T8)──┘  │
        CANCELLED                                          ▲                          │
                                                           └────────dispute(T8)───────┤
                                                                       verify(T6)─────┘──▶ VERIFIED
   EXPIRED: reserved (no transition — §3.5)
```

---

## §4. API Contract & Transport `[MVP]`

### §4.1 Transport & versioning

| Env | Gateway base | WebSocket |
|-----|--------------|-----------|
| Dev | `http://localhost:3000/api/v1` | `ws://localhost:3001` |
| Staging | `https://staging.idrm.gov.in/api/v1` | `wss://staging.idrm.gov.in/ws` |
| Prod | `https://api.idrm.gov.in/api/v1` | `wss://api.idrm.gov.in/ws` |

All endpoints are under **`/api/v1`**. Clients MUST go through the **Bun gateway** (`:3000`); the monolith
(`:8000`) is not directly reachable in production.

### §4.2 HTTP-method policy (D15)

IDRM uses **only `GET` and `POST`** (backend CORS allows only these). No `PUT`/`PATCH`/`DELETE`. All updates
and state changes are `POST`, via **action sub-endpoints** (`POST /services/{id}/approve`, …) — never a generic
status update. Profile update is `POST /users/me`.

### §4.3 Tokens (D8)

`POST /auth/login` → `{ access_token, refresh_token, token_type:"Bearer", expires_in:900, user }` (**900 s =
15 min**). Send `Authorization: Bearer <access>`; refresh at `POST /auth/refresh` before expiry (refresh lives
**7 days**). JWTs are **signed (HS256), not encrypted** — no secrets in the payload; the access token carries
`role`. `POST /auth/logout` is a 204 (stateless; client discards tokens — Redis denylist is `[FFP]`).

### §4.4 Conventions

- **List envelope:** `{ "status":"success", "data": <payload> }`; paginated payloads are
  `{ items, total, page, per_page, pages }`. Single resources/actions return the object directly.
- **Pagination:** `page` (default 1), `per_page` (default 20, **max 100**, clamped).
- **IDs:** UUIDs (`service_id`, `user_id`, `org_id`, `notification_id`); audit ids are BIGSERIAL ints.
- **Coordinates:** GeoJSON `[lon, lat]`, SRID 4326 (§5.1). **Enums:** exact UPPERCASE (§1); wrong case → 422.

### §4.5 Error model

`{ "detail":"…", "code":"…", "field":"…" }` (`code`/`field` optional). Codes: **200/201/204** · **400** ·
**401** (`WWW-Authenticate: Bearer`) · **403** (role) · **404** · **409** (status guard / accept race) ·
**422** (validation) · **429** (`{detail, code:"RATE_LIMITED", retry_after}` + `Retry-After`) · **500**.

### §4.6 Endpoint index (authoritative — from the live routers)

`main.py` mounts `auth, users, services, geo, notifications, analytics`. **24 routes:**

| Method · Path (`/api/v1`+) | Auth | Notes |
|---|---|---|
| GET `/health`, GET `/health/ready` | none | liveness / readiness (RFC-MGMT §4) |
| POST `/auth/register` | none | 201; self-roles (§2.2) |
| POST `/auth/login`, `/auth/refresh` | none | tokens |
| POST `/auth/logout` | req | 204 |
| GET `/users/me`, POST `/users/me` | req | own profile |
| POST `/services` | req | 201; create (§3.6) |
| GET `/services` | opt | `status,service_type,priority,mine,provider_id,page,per_page` |
| GET `/services/{id}` | opt | privacy-aware (§2.6) |
| POST `/services/{id}/{approve,reject,accept,start,complete,verify,cancel,dispute}` | req | lifecycle (§3.2) |
| GET `/geo/nearby`, `/geo/cluster` | none | §5 |
| GET `/notifications`, POST `/notifications/{id}/read` | req | §6.3 |
| GET `/analytics/dashboard` | req | RFC-MGMT §2 |

**Specified but unbuilt:** `POST /users/{id}/role` (C-AUTHZ-1); password-reset + phone/OTP (D9). The "37
endpoints" figure in README/CLAUDE is informational; **24 are mounted** (**C6**).

---

## §5. Geospatial Subsystem `[MVP]`

### §5.1 The coordinate rule (MUST)

All geometry is GeoJSON **`[longitude, latitude]`**, **SRID 4326**. Stored as PostGIS `POINT(lon lat)` via
`ST_SetSRID(ST_MakePoint(lon,lat),4326)`, read back as `[lon,lat]`. Leaflet clients MUST convert
(`[lat,lng]` ↔ `[lon,lat]`). Both geo endpoints are **public, read-only, identity-free** and consider only
**live** requests (`status IN (APPROVED, ACCEPTED, IN_PROGRESS)`).

### §5.2 `GET /geo/nearby`

Live requests within a radius, nearest first. Params: `latitude`, `longitude` (required), `radius` km (default
5, **clamped (0.1…50]**), `service_type?`. Realization: `ST_DWithin(::geography, radius_m)` (true metres),
`ST_Distance/1000` km (3-dp), `ORDER BY distance ASC`, `LIMIT 50`. Response: `{ center, radius_km, total,
results:[{service_id, service_type, priority, status, address, location:[lon,lat], distance_km}] }`.

### §5.3 `GET /geo/cluster`

K-means clusters for a zoomed-out map. Params: `zoom` (required, 1–20), `bounds?` (`south,west,north,east` —
four numbers or **400**). Realization: `ST_ClusterKMeans(location, k)` with `k = max(1, min(zoom*2, 50,
point_count))`; optional viewport `location && ST_MakeEnvelope(west,south,east,north,4326)`; centroid via
`ST_Centroid(ST_Collect(...))`; per-cluster `priority_breakdown` (CRITICAL/HIGH/MEDIUM/LOW). Empty → `{clusters:[]}`.

### §5.4 Safety

No identity leakage (no join to `users`). **Caller-supplied** values MUST be bound parameters; only
server-derived constants (the active-status literal, the validated integer `k`) are inlined. Bad `bounds` → 400.

---

## §6. Real-time, Notifications & Pub/Sub `[MVP]`

### §6.1 WebSocket endpoint

Clients open a socket to the **gateway** at `ws://localhost:3001` (a dedicated `Bun.serve`, separate from
`:3000`). On connect → `{"type":"connected"}`.

### §6.2 Subscribe protocol & channels

| Client → | Server → | Effect |
|---|---|---|
| `{type:"subscribe",channel}` | `{type:"subscribed",channel}` | join (`channel` defaults `service_requests`) |
| `{type:"unsubscribe",channel}` | `{type:"unsubscribed",channel}` | leave |
| `{type:"ping"}` | `{type:"pong"}` | keep-alive |
| invalid/unknown | `{type:"error",detail}` | no-op |

Channels: **`service_requests`** (map events) and **`notifications`** (per-user). Disconnect removes the socket
from all channels.

### §6.3 Notification object & lifecycle

A durable DB row served by `GET /notifications` + `POST /notifications/{id}/read`. API shape (`subject→title`,
`body→message`, `status→read`): `{ id, type, title, message, read, created_at, related_service_id }`; `type` ∈
`NotificationType` (§1). `GET /notifications` → `{status:"success", data:{items[…], unread_count}}` (newest
first). Created already `SENT`/unread; mark-read sets `READ`+`read_at` (own only, else 404; DB requires
`sent_at` before `read_at`). Lifecycle-triggered notifications (T3/T5) share the action's transaction (atomic).

### §6.4 Redis pub/sub bridge & guarantees

```
Backend ─publish_json─▶ Redis channel ─(gateway bridge)─▶ subscribed WS clients
```

Backend publishes to `service_requests` (identity-free map events) and `notifications` (`{user_id,
notification}`). `startRedisBridge()` subscribes and relays. **Best-effort (MUST NOT break the API):**
`publish_json` swallows Redis errors; without `REDIS_URL` the socket works but relays nothing. Publishes happen
**after commit** (the row is durable before anyone is told); the DB row + `GET` endpoints are the source of truth.

### §6.5 Map event types & reconnection

On `service_requests`: **`request_created`** / **`request_updated`**, payload `{type, request:{service_id,
service_type, priority, status, address, location:{type:"Point",coordinates:[lon,lat]}, created_at}}` (no
identity). `request_deleted` is reserved but **never emitted** (no delete — **C-RT-1**). The protocol is
stateless per connection: on reconnect a client MUST re-`subscribe` and reconcile by re-fetching (missed events
are not replayed).

---

## Appendix Z. Changes & open items

Consolidates the former six contract RFCs into one (faithful to RFC 2328 being a single spec). Code-grounded
gaps logged in **RFC-CLARIFY §2b**: C-VOCAB-1, C-AUTHZ-1, C-AUTHZ-2, C-LIFE-1, C-LIFE-2, C9, C12, C6, C-RT-1,
**C-COV-1** (no `disaster_event` entity). Rationale/context = RFC-ARCH; observability = RFC-MGMT; code layout =
RFC-IMPL.
