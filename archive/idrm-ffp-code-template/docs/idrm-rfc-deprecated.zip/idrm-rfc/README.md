# IDRM-RFC Series — Index, Conventions & Coverage

An **OSPF/Moy-style documentation suite** for IDRM: the system documented end-to-end, from *idea/inception* to
*implementation/completion*, mirroring John T. Moy's **four** OSPF artifacts. **RFCs are named, not numbered**
(`RFC-<SHORTNAME>`). This file is the series front-matter: the Moy lineage, the document set, the authoring
conventions, the validation gate, and the coverage matrix.

> **Methodology & resumption:** [`instructions/IDRM-RFC-SERIES-PLAN.md`](../../instructions/IDRM-RFC-SERIES-PLAN.md).

## Why four documents (not twelve)

Moy's OSPF corpus is **four artifacts**, each a different altitude — and RFC 2328 (the contract) is **one**
document with many sections, not many documents. The IDRM series matches that exactly: **four core RFCs**, one
per Moy layer, plus a living doubts log. (An earlier draft split the single contract into six files; those are
now the six **sections** of RFC-PROTOCOL.)

| Moy artifact | Layer | IDRM document |
|--------------|-------|---------------|
| *OSPF: Anatomy of an Internet Routing Protocol* | concept / rationale | **RFC-ARCH** |
| *OSPF Version 2* (RFC 2328) | normative contract | **RFC-PROTOCOL** (§1 Vocabulary · §2 Authorization · §3 Lifecycle ⭐ · §4 API · §5 Geo · §6 Real-time) |
| *OSPF MIB* (RFC 1850) | management / observability | **RFC-MGMT** |
| *OSPF Complete Implementation* | reference code + operations | **RFC-IMPL** |

## Document set

| RFC | Title | Track | Status |
|-----|-------|-------|--------|
| [RFC-ARCH](RFC-ARCH.md) | Architecture & Conceptual Overview ("Anatomy") | D narrative | 🔵 REVIEW |
| [RFC-PROTOCOL](RFC-PROTOCOL.md) ⭐ | The IDRM Normative Contract (vocab · authz · lifecycle · API · geo · real-time) | A normative | 🔵 REVIEW |
| [RFC-MGMT](RFC-MGMT.md) | Management, Observability & Analytics ("MIB") | B management | 🔵 REVIEW |
| [RFC-IMPL](RFC-IMPL.md) | Implementation & Operations Walkthrough | C implementation | 🔵 REVIEW |
| [RFC-CLARIFY](RFC-CLARIFY.md) | Clarifications, Open Questions & Recommended Path | meta (living) | 🟡 DRAFT |

Legend: 🟡 draft · 🔵 in review · ✅ stable.
**Reserved for FFP** (Full-Fledged Product; authored when each module is built): `RFC-FINANCE`, `RFC-CHATBOT`,
`RFC-MOBILE`, `RFC-MAD`, `RFC-MICRO`. Until then, FFP scope lives inside the four RFCs as `[FFP]` / `[MVP→FFP]`
tags.

## Conventions (govern every RFC)

- **Naming.** `RFC-<SHORTNAME>` — mnemonic, never numbered; order is the dependency graph, not an index.
- **Tracks.** A = normative contract · B = management · C = implementation · D = narrative · meta. Tracks A/B
  use **RFC-2119** keywords (MUST/SHOULD/MAY) in their precise sense, restated in each intro; Tracks C/D are
  **informative** and say so.
- **One vocabulary.** Every fixed-choice value is defined once in **RFC-PROTOCOL §1** and cited elsewhere.
- **Scope tags.** Every clause is `[MVP]`, `[FFP]`, or `[MVP→FFP]`.
- **Status lifecycle.** `DRAFT → REVIEW → STABLE`; RFC-CLARIFY stays living/DRAFT.
- **Template.** Header table (RFC, Track, Status, Requires, Source docs, dates) → Abstract → Introduction
  (scope/audience/non-goals/normative-language) → body → Appendix Z (changes & open items → RFC-CLARIFY).

## Validation gate (promotion to STABLE)

An RFC MUST pass: **(1) Vocabulary** — enums match RFC-PROTOCOL §1 exactly; **(2) Source-trace** — every claim
traces to a feeder doc or `src/`, and on **doc-vs-code conflict the code wins** (logged in RFC-CLARIFY);
**(3) Cross-reference** — all `Requires` resolve; **(4) Coverage** — all outline sections present, no stubs;
**(5) Decision-consistency** — nothing contradicts D1–D17 (`IDRM-PROJECT-STATUS.md`) without a dated override in
RFC-CLARIFY. **Series closure** = all four core RFCs STABLE + RFC-CLARIFY S1–S5 signed off.

## Coverage matrix (the non-RFC repo → where it's addressed)

Confirms the series addresses the whole system, not just the API.

| Repo area | Artifact(s) | Covered by |
|-----------|-------------|------------|
| Enums / CHECK constraints | `dbmodels/enums.py`, `02-schema.sql` | RFC-PROTOCOL §1 |
| Roles & permissions | `IDRM-FS.md` §3.3, `security.py`, `auth_service.py` | RFC-PROTOCOL §2 |
| Request lifecycle | `service_service.py`, FS §6.1 | RFC-PROTOCOL §3 ⭐ |
| HTTP API / routers | `api/v1/*`, `main.py`, gateway | RFC-PROTOCOL §4 |
| Geospatial | `geo_service.py`, DB Query Ref | RFC-PROTOCOL §5 |
| Real-time / notifications | `notification_service.py`, `core/redis.py`, gateway `websocket.ts` | RFC-PROTOCOL §6 |
| Analytics, audit, health, rate-limit, cache, SLOs | `analytics_service.py`, `audit_log.py`, `main.py`, `rateLimit.ts` | RFC-MGMT |
| 6 DB tables | users, organizations, service_requests, notifications, audit_logs, disaster_types | RFC-PROTOCOL §1–§6 + RFC-IMPL §6 |
| Backend M0–M6 / Gateway G1–G4 / Frontend F0–F6 + React | `src/**`, `IDRM-BUILD-WORKFLOW.md` | RFC-IMPL §2–§5 |
| Deploy / ports / Docker / DB init / scripts | `infra/**`, `database/init/**`, `scripts/**`, Ubuntu/Deploy guides | RFC-IMPL §8–§14 |
| Concept / PRD / HLD / architecture | README, CLAUDE, PRD, HLD, ARCHITECTURE-GUIDE | RFC-ARCH |
| **Not covered (intentionally)** | `dsml/` sub-project | out of scope — RFC-CLARIFY **S3** |
| **Gap surfaced** | "manage disaster events" permission with no `disaster_event` entity/endpoint | RFC-CLARIFY **C-COV-1** (`[FFP]`) |

The full series is drafted; the four core RFCs are in REVIEW pending the validation gate and product-owner
sign-off on RFC-CLARIFY S1–S5 before promotion to STABLE.
