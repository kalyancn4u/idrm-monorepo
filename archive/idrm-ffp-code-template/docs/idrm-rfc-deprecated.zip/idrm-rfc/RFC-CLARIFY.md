# RFC-CLARIFY: Clarifications, Open Questions & Recommended Path

| Field | Value |
|-------|-------|
| RFC | RFC-CLARIFY |
| Track | meta (living audit trail) |
| Status | DRAFT — **living document**, updated as the rest of the series is written |
| Requires | [`instructions/IDRM-RFC-SERIES-PLAN.md`](../../instructions/IDRM-RFC-SERIES-PLAN.md) |
| Source docs | corpus survey; `schedules/IDRM-PROJECT-STATUS.md` §5–6; doc-reconciliation memory |
| Created / Updated | 2026-06-30 |

## Abstract

This RFC is the **doubts-and-decisions ledger** for the IDRM-RFC series, written in **Auto-pilot mode**.
Per the request, it records every clarification needed to document IDRM faithfully, the **reasoning**, and
the **recommended path taken** so work proceeds without blocking — while flagging the few items that still
need **product-owner sign-off**. It is the IDRM analog of the "open issues / changes" appendices Moy kept
across the OSPF RFCs. It stays **living**: each judgment call made while writing the rest of the series is appended.

> **Decision convention.** Each item: **Q** (the doubt) · **Reasoning** · **➡️ Path** (what we'll do now) ·
> **Owner** (who, if anyone, must confirm). Items resolved by an existing locked decision cite it (D#).

---

## 1. Methodology / series-shape clarifications (resolved — proceeding)

**C1 — Is the OSPF four-artifact model the right frame for IDRM?**
*Reasoning:* Moy's split (Anatomy = concept, RFC 2328 = contract, RFC 1850 = MIB/management, Complete
Implementation = code) cleanly separates altitudes that IDRM currently blurs across 43 files. IDRM already
has the raw material in all four layers (PRD/architecture = concept; FS/API/json = contract;
analytics/monitoring = management; LLD/build-workflow/`src` = code). **➡️ Path:** adopt the four-track model
(Tracks D/A/B/C) as in the plan §1. **Owner:** none — methodological, reversible.

**C2 — RFC-style numbering vs. just better prose docs?**
*Reasoning:* The request explicitly cites RFCs "for Routing Protocols" and the "length and breadth … from
idea to completion." A numbered, cross-referenced, status-tracked series with RFC-2119 language gives the
contract parts real precision and makes completeness checkable. **➡️ Path:** numbered `IDRM-RFC-XXXX`
series in `docs/rfc/`, statuses DRAFT/REVIEW/STABLE. **Owner:** none.

**C3 — Where do the series files live without disrupting the existing 43-doc set?**
*Reasoning:* The repo already has `docs/`, `docs/development/`, `instructions/`, `start-here/`. A new
`docs/rfc/` keeps the series self-contained and discoverable; the **plan + prompt** go in `instructions/`
(developer-facing methodology) as the request asked ("document it in the instructions"). **➡️ Path:**
`docs/rfc/` for the series body + RFC-CLARIFY; `instructions/IDRM-RFC-SERIES-PLAN.md` for plan/prompt.
Add a pointer from the project `README.md`'s documentation map when the series is published. **Owner:** confirm at series sign-off.

**C4 — Generate the whole series now, or scaffold + resume?**
*Reasoning:* The request says to **break the task into modules, document the instructions + comprehensive
prompt, and emit here before proceeding** with the actual documentation, so it can be resumed. Writing 11
substantive RFCs in one pass would also bury judgment calls. **➡️ Path (this session, P0):** emit plan +
this ledger + index seed; **do not** write the series body yet. Resume via plan §8. **Owner:** none.

**C5 — Relationship to the existing canonical docs (FS §3.3 etc.).**
*Reasoning:* `IDRM-FS.md` §3.3 is already the locked source of truth for roles/permissions, and `IDRM-LLD.md`
for schema/API. The RFCs must **consolidate and re-frame**, not fork, these. **➡️ Path:** each RFC lists its
feeder docs; on any doc-vs-code conflict, **code wins** and it's logged here (matches the repo's existing
"build to canonical" rule). RFCs are a *view/contract layer* over the canonical docs, not a replacement.
**Owner:** confirm RFCs are additive, not authority-superseding, at sign-off.

---

## 2. Content clarifications surfaced by the corpus (recommended paths)

**C6 — Endpoint count: README says "37", CLAUDE lists more granular actions.**
*Reasoning:* The action sub-endpoints (`/approve`, `/accept`, `/start`, `/complete`, `/verify`, `/cancel`,
`/reject`, `/dispute`) plus auth/users/geo/analytics/notifications add up; "37" is an at-a-glance figure.
**➡️ Path:** RFC-PROTOCOL §4 builds the **authoritative endpoint index from the live `src/backend/app-python/api/v1`
routers** and reconciles the count there; treat "37" as informational until then. **Owner:** none (code-derived).
**✅ RESOLVED:** RFC-PROTOCOL §4.6 lists **24 routes mounted** today; "37" is informational. CLAUDE/README count flagged.

**C7 — `/start` action exists in code but is missing from CLAUDE.md's action list.**
*Reasoning:* PROJECT-STATUS §5a explicitly notes M3 added `ACCEPTED → IN_PROGRESS` via `/start`, not yet in
the CLAUDE summary. The state machine has 7 lifecycle actions, not 6. **➡️ Path:** RFC-PROTOCOL §3 documents `/start`
as a first-class transition; flag CLAUDE.md for a one-line follow-up (already a known backlog item).
**Owner:** none (code is canonical).

**C8 — Role count tension: "10 roles" (D1) vs older "6 roles" references.**
*Reasoning:* Reconciliation already locked **10 account roles + Public tier** (D1), with `EXECUTIVE`
Post-MVP and `AUDITOR` MVP-read-only (D3). Some legacy prose may still say 6. **➡️ Path:** RFC-PROTOCOL §1/§2 use
the locked 11-tier taxonomy; any stray "6 roles" is treated as stale and noted, not honored. **Owner:** none.

**C9 — Statuses: is `DISPUTED` in the main line or a side-protocol? Is `EXPIRED` automatic?**
*Reasoning:* D4 + CLAUDE define `DISPUTED` as raised from `IN_PROGRESS`/`COMPLETED`, resolving to
`IN_PROGRESS` or `REJECTED`; `EXPIRED` is a terminal state (timeout). These are sub/auto behaviors, not the
happy path. **➡️ Path:** RFC-PROTOCOL §3 models the happy path as the spine and `DISPUTED`/`EXPIRED` as a dispute
sub-protocol + expiry rule, with explicit triggers (who/what causes expiry — to be read from code/FS).
**Owner:** confirm the **expiry trigger** (time-based job vs. on-read) when writing RFC-PROTOCOL §3 — read code first.
**✅ RESOLVED:** `DISPUTED` is a side-state with only T8 (raise) + T9 (`→REJECTED`) built; resolve-to-`IN_PROGRESS`
is unimplemented (**C-LIFE-1**). **`EXPIRED` has NO transition or trigger in code** — reserved (RFC-PROTOCOL §3.5).

**C10 — Auto-approve scope: D5 says CRITICAL/HIGH auto-approve; M3 code auto-approves which exactly?**
*Reasoning:* CLAUDE/D5 say emergency/urgent auto-approve `SUBMITTED → APPROVED`. The M3 note says
"auto-approve CRITICAL/HIGH." **➡️ Path:** RFC-PROTOCOL §3.3 states the rule as **CRITICAL/HIGH** and cites the
`service_service.py` create path as the authority; if code differs, code wins + logged here. **Owner:** none.

**C11 — `/accept` takes `org_id` today; user↔org membership is a known gap.**
*Reasoning:* PROJECT-STATUS §5a flags that `/accept` currently takes `org_id` because there's no user↔org
membership model yet. **➡️ Path:** RFC-PROTOCOL §3 / RFC-IMPL document **current** behavior (org_id passed) and mark the
membership model as a forward item, not a contract promise. **Owner:** product/eng — note as future work.

**C12 — Privacy ↔ visibility interaction details (who sees PROTECTED contact, exactly).**
*Reasoning:* D7: default `PROTECTED`, raise-only, hides name/phone from public; responders get contact "via
the system." The precise rule (which roles, at which lifecycle state, get contact) must come from FS/code.
**➡️ Path:** RFC-PROTOCOL §2.6 derives the visibility matrix from FS §3.3 + the privacy-aware GET in
`service_service.py`. **Owner:** confirm responder-contact-disclosure rule against FS when writing RFC-PROTOCOL §2.
**✅ RESOLVED (RFC-PROTOCOL §2.6):** non-PUBLIC contact is visible only to the requestor or
`{ADMIN, DM_AUTHORITY, MANAGER, EVENT_MANAGER, AUDITOR}`. The intended "assigned provider gets contact via the
system" is **NOT implemented** — `PROVIDER` is not a privileged viewer; awaits the user↔org membership model.

**C13 — SLO/target numbers (D11) belong in the "MIB" RFC — confirm the canonical set.**
*Reasoning:* D11 lists p95<500ms (per-category), page<3s, DB<100ms, satisfaction 4.0 MVP/4.5 scale, uptime
99.5%→99.9%. These are the observable targets. **➡️ Path:** RFC-MGMT tables exactly these as the SLOs.
**Owner:** none (locked decision).

---

## 2b. Code-grounded findings (discovered & resolved while writing Tracks A/B/C)

Each is a **doc-vs-code or specified-but-unbuilt** gap found by reading `src/`. Per the "code wins" rule, the
RFCs document the **as-built** behavior and flag the doc; none blocks the series.

| ID | Finding | Where | Recommended path |
|----|---------|-------|------------------|
| **C-VOCAB-1** | `OrgType`, `NotificationChannel`, `NotificationStatus`, CamelCase `AuditResourceType` exist in `enums.py` but not in CLAUDE.md | RFC-PROTOCOL §1 | documented (authoritative); one-line CLAUDE follow-up |
| **C-AUTHZ-1** | `POST /users/{id}/role` (role grant) specified in CLAUDE but **unimplemented** (only `/users/me`) | RFC-PROTOCOL §2.2, §4.6 | document as specified-but-unbuilt; implement when role admin lands |
| **C-AUTHZ-2** | FS matrix lets **Manager** accept; code `_PROVIDER_ROLES={PROVIDER,ADMIN}` excludes it | RFC-PROTOCOL §2.4 | code wins; reconcile FS matrix or code at owner's call |
| **C-LIFE-1** | `DISPUTED → IN_PROGRESS` (resolve-and-continue) in FS but unbuilt; only `→REJECTED` exists | RFC-PROTOCOL §3.2 | document T9 only; mark continue-path `[MVP→FFP]` |
| **C-LIFE-2** | Action-body fields `notes`/`estimated_arrival`/`reason` (approve/accept/cancel/dispute) accepted but **not persisted** (audit-only) | RFC-PROTOCOL §3.6 | document as audit-captured; add DB columns later if needed |
| **C-RT-1** | `request_deleted` WS token in vocabulary but **never emitted** (no delete in IDRM) | RFC-PROTOCOL §6.5 | reserved; keep for symmetry |
| **C-COV-1** | "Manage disaster events" permission has **no `disaster_event` entity/endpoint** (only `disaster_types` lookup) | RFC-PROTOCOL §2.3, RFC-IMPL §6 | document as `[FFP]`; build the entity when events ship |
| **C-MGMT-1** | No Prometheus/`/metrics` exporter built (Monitoring Guide describes one) | RFC-MGMT §8 | SLO measurement external for now; build exporter `[MVP→FFP]` |
| **C-MGMT-2** | `request_id` audit column exists but not propagated gateway→backend | RFC-MGMT §8 | wire request-tracing `[MVP→FFP]` |
| **C-OPS-1** | App Dockerfiles + `nginx.conf` are empty placeholders (compose `app` profile blocked) | RFC-IMPL §12 | author images before staging bring-up |
| **C-OPS-2** | CI workflow files (`.github/workflows/*.yml`) are empty placeholders | RFC-IMPL §13 | author pipelines (PROJECT-STATUS §5b) |

---

## 3. Items genuinely needing product-owner sign-off (do not auto-resolve)

These mirror PROJECT-STATUS §6 and are **not** decided by code or prior decisions:

**S1 — Confirm MAD & Finance/Donations stay Post-MVP.** (Assumed per D13.) RFCs will document them as
**Post-MVP / out-of-scope** unless told otherwise. **Owner: product owner.**

**S2 — Frontend page-set / e-commerce-stub deletion.** Already actioned in F1 build, but formal page
inventory belongs in RFC-IMPL; confirm the canonical IDRM page set. **Owner: product owner.**

**S3 — Keep or remove the stray `dsml/` sub-project.** It's unrelated to IDRM's MVP. RFCs will **exclude**
it from scope and note it as out-of-tree pending a keep/remove call. **Owner: product owner.**

**S4 — FFP scope. ✅ RESOLVED (2026-06-30).** FFP = **Full-Fledged Product** — the mature, post-MVP IDRM,
the **same domain scaled up**, *not* a separate project. It absorbs the growth targets + Post-MVP modules
(Finance/Donations, AI Chatbot, native mobile, MAD, `EXECUTIVE` role, `AUDITOR` scoring, pan-India scale,
12+ languages, microservices migration). **➡️ Path:** **one continuous series**; tag every clause
`[MVP]` / `[FFP]` / `[MVP→FFP]` (plan §7); FFP-only modules become **appended named RFCs** (`RFC-FINANCE`,
`RFC-CHATBOT`, `RFC-MOBILE`, `RFC-MAD`, `RFC-MICRO`) authored when built (reserved in the README index).
The Track-A MVP contract (RFC-PROTOCOL §1–§6) is written so FFP
**extends without breaking** them. No clone, no separate vocabulary. **Owner:** none — framing locked;
confirm the individual Post-MVP→FFP module list at series sign-off (overlaps S1).

**S5 — RFC authority level.** Are the RFCs **informative views** over the canonical FS/LLD, or do they
**become** the new source of truth? Recommended (C5): additive view/contract layer that cites canonical docs.
**Owner: product owner** — affects how aggressively we'd later trim FS/LLD overlap.

---

## 4. Running log (appended as RFCs are written)

| Date | RFC being written | New judgment call | Path taken |
|------|-------------------|-------------------|------------|
| 2026-06-30 | P0 scaffolding | C1–C13, S1–S5 above | recorded; series scaffolded, body deferred to resumption |
| 2026-06-30 | P0 follow-up | S4 clarified: **FFP = Full-Fledged Product** (mature post-MVP IDRM, same domain) | one continuous series + `[MVP]`/`[FFP]`/`[MVP→FFP]` scope tags; FFP modules = appended named RFCs (RFC-FINANCE…); plan §7 rewritten |
| 2026-06-30 | P0 follow-up | Owner: **name RFCs, don't number** them | switched series to `RFC-<SHORTNAME>`; renamed this file to `RFC-CLARIFY.md`; plan/README updated |
| 2026-06-30 | RFC-SERIES, RFC-VOCAB, RFC-ARCH written | **C-VOCAB-1:** `OrgType`, `NotificationChannel`, `NotificationStatus`, CamelCase `AuditResourceType` exist in `dbmodels/enums.py` but not in CLAUDE.md §Key-Constraints | documented all in RFC-VOCAB (code is authoritative); flagged CLAUDE.md for a one-line follow-up |
| 2026-06-30 | RFC-VOCAB | Confirmed lowercase exceptions to the UPPERCASE rule: languages (`en/hi/te`), audit types (CamelCase), WS event tokens (`request_*`) | codified as RFC-VOCAB §2.3 conventions |
| 2026-06-30 | RFC-AUTHZ | Read FS §3.3 + `security.py` + role sets | matrix transcribed verbatim; **C-AUTHZ-1** (role-grant unbuilt) + **C-AUTHZ-2** (Manager-accept mismatch) logged; C12 resolved (provider-contact unbuilt) |
| 2026-06-30 | RFC-LIFECYCLE ⭐ | Read `service_service.py` transition-by-transition | T0–T9 table built from code; **C9** resolved (EXPIRED unbuilt), **C-LIFE-1/2** logged; auto-approve = CRITICAL/HIGH confirmed (C10) |
| 2026-06-30 | RFC-API | Built endpoint index from routers + `main.py` | **C6** resolved (24 routes mounted, "37" informational) |
| 2026-06-30 | RFC-GEO / RFC-REALTIME | Read geo/notification/redis/gateway code | contracts match code; **C-RT-1** (`request_deleted` unemitted) logged |
| 2026-06-30 | RFC-MGMT | Read analytics/audit/rate-limit/health | managed objects + SLOs (D11) tabled; **C-MGMT-1/2** observability gaps logged |
| 2026-06-30 | RFC-IMPL / RFC-OPS | Consolidated build workflow + infra | verification status + porting notes captured; **C-OPS-1/2** placeholder gaps logged |
| 2026-06-30 | **Consolidation (owner: "reduce the doc count")** | 12 docs over-fragmented vs Moy's **4 artifacts** | merged 6 contract RFCs → **RFC-PROTOCOL** §1–§6; folded RFC-OPS → RFC-IMPL §8–§14; folded RFC-SERIES → README. **Now 4 core RFCs + README + this log.** Coverage audit of non-RFC repo added to README; surfaced **C-COV-1** (no `disaster_event` entity) |

> Running-log rows dated before the consolidation name the original split documents (RFC-VOCAB, RFC-AUTHZ,
> RFC-LIFECYCLE, RFC-API, RFC-GEO, RFC-REALTIME, RFC-OPS, RFC-SERIES); their content now lives in
> **RFC-PROTOCOL §1–§6**, **RFC-IMPL §8–§14**, and the **README**, respectively. They are kept as the
> authoring history.

> Append one row per non-obvious decision made while writing the series. When an `S#` item is answered by the
> product owner, record the answer here and update the affected RFC.
