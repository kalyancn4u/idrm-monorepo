# RFC-IMPL: Implementation & Operations Walkthrough

| Field | Value |
|-------|-------|
| RFC | RFC-IMPL |
| Track | C (implementation & operations — informative) |
| Status | REVIEW |
| Requires | RFC-PROTOCOL, RFC-MGMT |
| Supersedes | the former RFC-OPS (now §8–§13) |
| Source docs | `IDRM-BUILD-WORKFLOW.md`; `IDRM-PROJECT-STATUS.md` §4/§4b; `IDRM-LLD.md`, `IDRM-HLD.md`; `IDRM-UBUNTU-PORTS-AND-ENVIRONMENTS.md`; `IDRM-DEPLOYMENT-GUIDE.md`; `infra/docker/*`, `database/init/*`, `scripts/*`; the live `src/` tree |
| Created / Updated | 2026-06-30 |

## Abstract

This RFC is the **reference-implementation and operations** layer — the analog of Moy's *OSPF Complete
Implementation*. It documents *how the RFC-PROTOCOL contract is realized in code and run in production*: the
data-flow architecture, the backend/gateway/frontend modules, the recurring data structures and patterns, the
verification status, and then (§8+) the deployment, environments, ports, database, and operational runbook. It
is **informative**: it documents the code as built; requirements live in RFC-PROTOCOL and RFC-MGMT.

## 1. Implementation architecture & data flow `[MVP]`

```
Browser ──HTTP──▶ Bun Gateway (:3000) ──proxy──▶ FastAPI monolith (:8000) ──async──▶ Postgres16/PostGIS3.4
   │                   │  (JWT verify, rate-limit, CORS, X-User-* inject)              │
   └──WebSocket(:3001)─┘◀──relay── Redis pub/sub ◀──publish(best-effort)───────────────┘
```

A request enters the gateway, which verifies the JWT, rate-limits (RFC-MGMT §5), injects trusted `X-User-*`
(RFC-PROTOCOL §2.5), and proxies to the monolith. Thin route handlers (`api/v1/*`) delegate to service modules
(`services/*`) using **async SQLAlchemy + GeoAlchemy2**. State changes publish best-effort events to Redis,
relayed to WebSocket clients (RFC-PROTOCOL §6).

## 2. Backend modules M0–M6 `[MVP]`

| Module | Builds | Key files |
|--------|--------|-----------|
| **M0** boot | app + CORS (GET/POST only) + health/readiness + async DB session | `main.py`, `core/{config,database}.py` |
| **M1** models/schemas | 5 ORM models + 11 enums (RFC-PROTOCOL §1) + Pydantic v2 schemas; GeoAlchemy2 `POINT`/4326 | `dbmodels/*`, `schemas/*` |
| **M2** auth | bcrypt(12) + JWT access/refresh + `get_current_user`; register/login/refresh/logout; `/users/me` | `core/security.py`, `services/auth_service.py`, `api/v1/{auth,users}.py` |
| **M3** services | the full lifecycle (RFC-PROTOCOL §3): create+auto-approve, list/get (privacy-aware), 8 actions; race-safe accept | `services/service_service.py`, `api/v1/services.py` |
| **M4** geo | `/geo/nearby` + `/geo/cluster` via raw parameterized PostGIS (RFC-PROTOCOL §5) | `services/geo_service.py`, `api/v1/geo.py` |
| **M5** notifications | durable notifications + Redis publish; emissions on accept/complete | `services/notification_service.py`, `core/redis.py`, `api/v1/notifications.py` |
| **M6** analytics | dashboard metrics, Redis-cached 5 min (RFC-MGMT §2) | `services/analytics_service.py`, `api/v1/analytics.py` |

## 3. Gateway modules G1–G4 `[MVP]`

| Module | Builds | Key file |
|--------|--------|----------|
| **G1** proxy | `Bun.serve` :3000 proxying `/api/*`→:8000; CORS preflight; security+CORS headers; 30 s timeout→504 | `src/{index,routes/api}.ts` |
| **G2** rate-limit | per-IP/endpoint fixed-window → 429 (RFC-MGMT §5); in-memory or Redis (fail-open) | `src/middleware/rateLimit.ts` |
| **G3** JWT auth | dependency-free HS256 verify; inject `X-User-ID`/`X-User-Role`; strip client `X-User-*` (anti-spoof) | `src/utils/jwt.ts`, `src/middleware/auth.ts` |
| **G4** WebSocket | dedicated :3001 socket; subscribe registry; Redis→WS relay (RFC-PROTOCOL §6) | `src/routes/websocket.ts` |

## 4. Frontend F0–F6 (web-html) + React SPA Part D `[MVP]`

- **web-html** (citizens, :5173, Vite+Tailwind Slate+Emerald): F0 setup + dependency-free fetch client
  (Bearer + proactive/reactive refresh) · F1 public · F2 auth · F3 citizen core (Leaflet pin, GeoJSON
  `[lon,lat]`) · F4 live map (priority markers / clusters by zoom + WS refresh) · F5 notifications+profile ·
  F6 provider (accept/start/complete).
- **React SPA Part D** (admins, :5174, Vite+TS, Zustand+React Query+Recharts): Login · Dashboard · approval
  queue. Deferred: user/provider mgmt, role-grant UI, admin LiveMap, live WS. **Mobile (Expo)** is `[FFP]`.

## 5. Recurring data structures & patterns `[MVP]`

- **Async ORM + GeoAlchemy2** (D14); geometry as PostGIS `POINT`/4326, `to_shape` (`.x`=lon, `.y`=lat).
- **Race-safe accept:** `SELECT … FOR UPDATE` on `APPROVED AND provider_id IS NULL` (RFC-PROTOCOL §3.4).
- **DB-owned side-effects:** triggers maintain `updated_at`, org stats, the immutable audit log (RFC-MGMT §3) —
  never duplicated in the service layer.
- **Best-effort Redis:** publish/cache helpers swallow errors — real-time/caching never break an API call.
- **Dependency-free clients:** web-html API client and the gateway JWT verify use no third-party libs.
- **Privacy at serialization:** `_can_see_contact` gates identity in `ServiceOut` (RFC-PROTOCOL §2.6).

## 6. Data model (6 tables) `[MVP]`

`users`, `organizations`, `service_requests`, `notifications`, `audit_logs`, and the `disaster_types` lookup
table. Mapping: users→§2 (auth/roles); organizations→provider orgs (§3.4); service_requests→§3 (lifecycle);
notifications→§6; audit_logs→RFC-MGMT §3; disaster_types→reference data. **There is no `disaster_event`
entity** — the matrix permission "manage disaster events" has no backing table/endpoint (**C-COV-1**, `[FFP]`).
There are **no `/organizations` CRUD routes** (orgs are seeded/admin-managed).

## 7. Verification status `[MVP]`

Per `IDRM-PROJECT-STATUS.md` §4b, code is written/reviewed; most runtime verification is **pending on Ubuntu**
(the Windows authoring box has no Python/Postgres/Redis — §13). **Actually run:** G1 proxy (Bun 1.3.9), G3 JWT
crypto (5/5), G4 bundle check. **Pending Ubuntu:** all backend M0–M6 round-trips, G2 live limits, full
token→backend flow, all frontend flows. Each module carries an inline **✅ Verify** block in
`IDRM-BUILD-WORKFLOW.md`.

---

## 8. Operations: target platform & authoring caveat `[MVP]`

> **🚩 Authoring ≠ target.** The repo is **written on Windows for authoring only** — no Python/conda,
> PostgreSQL/PostGIS, or Redis, and Bun-on-Windows misbehaves. **Do not build, run, migrate, or verify on
> Windows.** The **development/target platform is an Ubuntu laptop**; all building, running, migrations, and
> verification happen there. Every guide command is an **Ubuntu** command
> (`docs/IDRM-UBUNTU-PORTS-AND-ENVIRONMENTS.md`).

## 9. Ports & firewall `[MVP]`

| Port | Service | Exposure |
|------|---------|----------|
| 5173 / 5174 | web-html / React SPA (Vite) | dev |
| 3000 / 3001 | Bun Gateway — HTTP / WebSocket (front door) | public |
| 8000 | FastAPI monolith | internal (behind gateway) |
| 5432 / 6379 | PostgreSQL / Redis | internal |

In production only 3000/3001 (fronted by NGINX, SSL) are public; the monolith, Postgres, and Redis stay
internal. `ufw` rules + open/check/free procedures are in the Ubuntu ports guide.

## 10. Environments: dev / staging / prod `[MVP]`

- **Development (native, 5 terminals):** Postgres+Redis up, then (1) `uvicorn main:app --reload --port 8000`
  (conda `idrm-mvp`), (2) gateway `bun run dev`, (3) web-html `bun run dev`, (4) React `bun run dev`, (5) Expo
  `[FFP]`. Setup: `scripts/setup-development-monolith.sh`.
- **Staging (Docker):** `docker-compose -f infra/docker/full-stack.yml up -d`, then `… exec backend alembic
  upgrade head`. Setup: `scripts/setup-staging.sh`.
- **Production:** `scripts/setup-production.sh` — NGINX → blue/green Docker → Prometheus+Grafana → automated
  Postgres backups.

## 11. Database init & migrations `[MVP]`

```
psql … -f database/init/01-extensions.sql   # PostGIS, uuid-ossp, pg_trgm
psql … -f database/init/02-schema.sql        # tables, indexes, views, triggers, CHECKs
psql … -f database/init/03-seed-data.sql     # disaster_types reference rows
```

`02-schema.sql` is the authority for the **CHECK constraints** behind RFC-PROTOCOL §1 and the triggers behind
RFC-MGMT §3. **Alembic migrations are pending** (D14) — init scripts are current; versioned migrations are a
known backlog item.

## 12. Docker, secrets & the production guard `[MVP]`

`infra/docker/full-stack.yml` composes the stack. **Gap (C-OPS-1):** the app **Dockerfiles** and
`infra/docker/nginx.conf` are still empty placeholders — the compose `app` profile needs them. Config comes
from `.env` (`core/config.py`); `setup-production.sh` **refuses** if the dev password or `change-in-production`
JWT secret would reach production. Secrets MUST NOT be committed; `JWT_SECRET_KEY` MUST be a strong production
value (tokens per RFC-PROTOCOL §4.3).

## 13. Runbook, health checks & CI `[MVP]`

- **Liveness/readiness:** `GET /api/v1/health` + `/health/ready` (RFC-MGMT §4); `redis-cli ping`,
  `psql … "SELECT 1"`.
- **Fresh bring-up:** `scripts/setup-prerequisites.sh` reports Bun / Python(conda) / PostgreSQL 16 / PostGIS
  3.4 / Redis 7.2.
- **Per-module verification** is inline in `IDRM-BUILD-WORKFLOW.md` (**✅ Verify** blocks); status in
  `IDRM-PROJECT-STATUS.md` §4b (§7).
- **CI/CD (C-OPS-2):** the GitHub Actions workflows (`.github/workflows/{unit,integration,component,e2e}.yml`)
  are empty placeholders.

## 14. Porting notes (Windows authoring → Ubuntu target) `[MVP]`

The repo is authored on Windows but built/run/verified on Ubuntu. All shell commands in the guides are Ubuntu
commands. Pilot footprint: 2 districts (Hyderabad + Vijayawada, D10); pan-India scale + the microservices
migration are `[FFP]` (future RFC-MICRO).

## Appendix Z. Changes & open items

- Folds the former RFC-OPS in as §8–§14. Gaps logged in RFC-CLARIFY: user↔org membership, role-grant endpoint
  (C-AUTHZ-1), Prometheus exporter (C-MGMT-1), `EXPIRED` sweep (C9), dispute-continue (C-LIFE-1), no
  `disaster_event` (C-COV-1), empty Dockerfiles/CI (C-OPS-1/2), Alembic pending (D14).
