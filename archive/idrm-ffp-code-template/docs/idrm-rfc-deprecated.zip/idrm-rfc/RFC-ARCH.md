# RFC-ARCH: Architecture & Conceptual Overview ("Anatomy")

| Field | Value |
|-------|-------|
| RFC | RFC-ARCH |
| Track | D (narrative — informative) |
| Status | REVIEW |
| Requires | RFC-PROTOCOL (forward reference) |
| Updates | — |
| Source docs | `README.md`, `CLAUDE.md`, `docs/IDRM-ARCHITECTURE-GUIDE.md`, `docs/development/IDRM-PRD.md`, `schedules/IDRM-PROJECT-STATUS.md` (§3 decisions) |
| Created / Updated | 2026-06-30 |

## Abstract

This RFC is the **conceptual narrative** for IDRM — the IDRM analog of Moy's *OSPF: Anatomy of an Internet
Routing Protocol*. It answers *why the system is shaped the way it is*: the disaster-response problem it
solves, the "Uber for disaster relief" request journey, the three-frontend modular-monolith architecture and
the technology choices behind it, the explicit scope boundary between the MVP and the Full-Fledged Product
(FFP), and the dated decision history (D1–D17) that the rest of the series builds to. It is **informative**:
it explains and motivates, but imposes no requirements — those live in the Track-A RFCs.

## 1. Introduction

**Scope.** The problem, the solution metaphor, the architecture rationale, scope, and decision history.
**Audience.** Newcomers, architects, reviewers, and anyone needing the "why" before the "what."
**Non-goals.** The exact contract (RFC-PROTOCOL) and code detail (RFC-IMPL). Cross-references point there.
**Normative language.** Track D — **informative**. No new MUSTs; requirement-bearing statements cite the
governing Track-A/B RFC.

## 2. The problem `[MVP]`

When disasters strike India — floods, cyclones, earthquakes, pandemics — coordination, not scarcity, is often
the bottleneck:

- **Citizens** in crisis don't know where or how to request help.
- **Responders** (NGOs, hospitals, volunteers, government) can't see where help is needed.
- **No coordination** exists across the responding organizations.
- **No tracking** of whether the response actually closed the loop.

IDRM (Integrated Disaster Response Management) is a government-backed, map-driven platform that connects
citizens in crisis with the responders who can help, and tracks every request to completion. The **MVP** is a
**2-district pilot — Hyderabad + Vijayawada** (D10); pan-India scale is an FFP goal (§5).

## 3. The solution metaphor & request journey `[MVP]`

"**Uber for disaster relief**": a citizen raises a need, it appears on a live map, an authority approves it, a
nearby provider accepts and delivers, and the citizen verifies completion. The canonical journey:

1. **Citizen** creates a request ("Need food at T Nagar") with a map location and priority.
2. **DM Authority** reviews it on the map and approves (or the system auto-approves emergencies).
3. **System** notifies nearby providers (in-app now; SMS/push are FFP).
4. **Provider** accepts → starts → marks complete.
5. **Citizen** verifies completion and rates the provider.
6. **Everyone** tracks state in real time — full transparency.

This journey **is** the IDRM "routing protocol"; its formal state machine is **RFC-PROTOCOL §3** (the flagship,
analogous to OSPF's neighbor FSM). The vocabulary it moves through (statuses, priorities, types) is RFC-PROTOCOL §1.

## 4. Architecture: three frontends, one monolith — and why `[MVP]`

```
3 Frontends  →  Bun API Gateway (:3000 HTTP, :3001 WS)  →  FastAPI Modular Monolith (:8000)  →  PostgreSQL 16 + PostGIS 3.4 · Redis 7.2
```

**One backend, three faces.** A single FastAPI **modular monolith** (modules `/auth`, `/services`, `/geo`,
`/analytics`, `/notifications` on port 8000) serves three frontends: an **HTML/Tailwind** citizen web app
(:5173), a **React SPA** admin dashboard (:5174), and a **React Native/Expo** field app (**`[FFP]`**; the MVP
ships responsive web). A **Bun API Gateway** is the single front door — routing, CORS, rate-limiting, JWT
verification, and the WebSocket fan-out.

**Why a modular monolith (not microservices) `[MVP→FFP]`.** For a 2-district pilot, one deployable process is
simpler to run, reason about, and verify than a fleet of services; the modular boundaries keep the eventual
**microservices migration an FFP option** (`archive/MIGRATION-TO-MICROSERVICES-v3.md`, future `RFC-MICRO`)
without paying its cost now.

### 4.1 Technology decisions & rejected alternatives

| Chosen | Rejected | Why (informative) |
|--------|----------|-------------------|
| **Bun** gateway | Node.js | Faster startup/throughput; native WS, Redis, and bundling without a dependency stack |
| **FastAPI modular monolith** | Microservices | One process to run/verify for a pilot; module seams preserve the future split |
| **Python geospatial in-process** | Java / GeoServer | Keeps geo inside the monolith; no separate JVM service to operate |
| **PostGIS** on PostgreSQL 16 | App-side geo math | Spatial indexing + `ST_DWithin`/`ST_ClusterKMeans` in the database |
| **Miniconda** | venv / pip | Manages the GDAL/GEOS binary geospatial dependencies cleanly |
| **Redis 7.2** | In-app state | Sessions, rate-limit counters, analytics cache, and pub/sub for real-time |

> **Authoring vs. target environment.** The repo is *authored* on a Windows box that has **no** Python/conda,
> Postgres/PostGIS, or Redis (and Bun-on-Windows misbehaves). **All building, running, migrating, and
> verifying happen on the Ubuntu dev laptop.** This caveat is operationalized in RFC-IMPL §8+.

## 5. Scope: MVP vs FFP

**In the MVP `[MVP]`:** citizen request lifecycle, DM approval, provider fulfilment, geospatial nearby/cluster,
real-time map + notifications (in-app), analytics dashboard, 10 roles + Public, 3 languages (en/hi/te),
responsive web (HTML + React SPA).

**Deferred to the FFP `[FFP]`:** Finance/Donations module, AI Chatbot, native mobile app (React Native/Expo),
the MAD module, the `EXECUTIVE` role and `AUDITOR` credibility/expense scoring, pan-India / 100k-MAU scale,
12+ languages, and the microservices migration. Each becomes its own named RFC when built (RFC-FINANCE,
RFC-CHATBOT, RFC-MOBILE, RFC-MAD, RFC-MICRO). The MVP→FFP framing is RFC-CLARIFY **S4** (resolved); the
contract RFCs are written so FFP extends them without breaking existing MUSTs.

## 6. Decision history (D1–D17) `[MVP]`

The locked decisions the whole series builds to (source: `schedules/IDRM-PROJECT-STATUS.md` §3, reconciled
2026-05-30/31). **Source of truth for roles/permissions = `IDRM-FS.md` §3.3.**

| # | Decision |
|---|----------|
| D1 | **10 account roles + Public tier** (expanded from the old 6) |
| D2 | **"Event Admin" = `DM_AUTHORITY`** (a GO or NGO); `EVENT_MANAGER` runs an event instance below it |
| D3 | `EXECUTIVE` = **FFP**; `AUDITOR` = MVP **read-only** (scoring is FFP) |
| D4 | **10 statuses**; happy path uses `ACCEPTED` (not `ASSIGNED`); dropped `DRAFT`/`CLOSED` |
| D5 | **Emergencies auto-approved** — `CRITICAL`/`HIGH` go `SUBMITTED → APPROVED` by the system |
| D6 | **6 service types**; "Clothing" → `OTHER` + description |
| D7 | **3 privacy levels**, default `PROTECTED`, **raise-only** |
| D8 | **Auth**: 15-min access + 7-day refresh, `Authorization: Bearer` (httpOnly cookie optional) |
| D9 | **Guest access** = phone + OTP quick-start → lightweight verified `CITIZEN` (deferred: needs SMS provider) |
| D10 | **MVP scope** = 2-district pilot (Hyderabad + Vijayawada); pan-India/100k = growth targets |
| D11 | **Targets**: API p95 <500ms (per-category), page <3s, DB <100ms; satisfaction 4.0 MVP/4.5 scale; uptime 99.5%→99.9% |
| D12 | **Languages**: en, hi, te (12+ = growth target) |
| D13 | **Out of MVP**: Finance/Donations, AI Chatbot, native mobile, MAD |
| D14 | **Backend data layer** = SQLAlchemy 2.0 async + GeoAlchemy2; Alembic migrations |
| D15 | **API** = GET/POST only, under `/api/v1`, action sub-endpoints (`/{id}/approve|accept|…`) |
| D16 | **UI** = Slate + Emerald; priority colors Critical=red/High=orange/Medium=amber/Low=green |
| D17 | **Version** stays 3.0 ("reconciled 2026-05-30") |

These map onto the contract: D1–D3 → RFC-PROTOCOL §2; D4–D7 → RFC-PROTOCOL §1+§3; D8/D9/D15 → RFC-PROTOCOL §4;
D11 → RFC-MGMT; D10/D13 → §5 scope; D14/D16 → RFC-IMPL.

## 7. Forward map to the rest of the series

| You want… | Read |
|-----------|------|
| The exact legal values | RFC-PROTOCOL §1 |
| Who can do what | RFC-PROTOCOL §2 |
| The request lifecycle ⭐ | RFC-PROTOCOL §3 |
| The HTTP contract | RFC-PROTOCOL §4 |
| Maps & geo queries | RFC-PROTOCOL §5 |
| Real-time & notifications | RFC-PROTOCOL §6 |
| Metrics, audit, SLOs | RFC-MGMT |
| How the code does it & running it | RFC-IMPL |
| Open questions | RFC-CLARIFY |

## Appendix Z. Changes & open items

- Scope items pending product-owner sign-off (RFC-CLARIFY): **S1** (MAD/Finance stay FFP), **S2** (canonical
  page set), **S3** (the stray `dsml/` sub-project in/out), **S4** (FFP framing — resolved), **S5** (RFC
  authority vs FS/LLD).
- This RFC is informative; all requirement-bearing detail is in the Track-A/B RFCs it points to.
