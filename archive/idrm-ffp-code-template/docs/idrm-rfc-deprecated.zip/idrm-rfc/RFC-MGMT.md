# RFC-MGMT: Management, Observability & Analytics ("MIB")

| Field | Value |
|-------|-------|
| RFC | RFC-MGMT |
| Track | B (management & observability) |
| Status | REVIEW |
| Requires | RFC-PROTOCOL |
| Updates | — |
| Source docs | `services/analytics_service.py`; `dbmodels/audit_log.py`; `main.py` health; `api-gateway/src/middleware/rateLimit.ts`; `core/redis.py`; `COMPLETE-MONITORING-GUIDE.md`; `IDRM-Redis-Operations.md`; decision D11 |
| Created / Updated | 2026-06-30 |

## Abstract

This RFC is IDRM's **MIB** — the analog of Moy's OSPF MIB (RFC 1850). It defines the system's **managed
objects**: the analytics dashboard metrics, the immutable audit-log record, the health/readiness probes, the
gateway rate-limit counters and their headers, the Redis cache keys and TTLs, and the service-level objectives
(SLOs) the system is measured against. It answers "what can an operator watch, measure, and tune?" — and flags
what is **not yet observable**.

## 1. Introduction

**Scope.** The observable + tunable surface: metrics, audit, health, rate limits, cache, SLOs.
**Audience.** Operators/SRE, backend devs, reviewers.
**Non-goals.** The behaviors being measured (RFC-PROTOCOL); deployment/runbook (RFC-IMPL §8+).
**Normative language.** Track B — RFC-2119 for the observable contract.

## 2. Managed object: analytics dashboard `[MVP]`

`GET /analytics/dashboard` (auth required) returns `{ status:"success", data: { … } }` where `data` is:

| Field | Meaning |
|-------|---------|
| `total_requests` | all requests (sum of `by_status`) |
| `active_requests` | count in `{SUBMITTED, APPROVED, ACCEPTED, IN_PROGRESS}` |
| `avg_response_time_min` | mean minutes from `created_at`→`accepted_at`, over accepted requests |
| `completion_rate` | `(COMPLETED + VERIFIED) / total`, 2-dp (0.0 if none) |
| `by_service_type` | count per `ServiceType` — **all 6 keys**, seeded 0 |
| `by_status` | count per `ServiceStatus` — **all 10 keys**, seeded 0 |

The response shape MUST be stable: every enum key is present even at count 0. The result is **cached in Redis 5
minutes** (`cache_set_json`, key `analytics:dashboard`, TTL 300); the cache is best-effort — a miss/outage
recomputes from Postgres.

## 3. Managed object: audit-log record `[MVP]`

The `audit_logs` table is an **immutable, append-only** action trail. Rows MUST NOT be updated or deleted, and
are **written by DB triggers** (`audit_service_request_changes` on every insert/status change) — the service
layer MUST NOT hand-write them. Schema (`AuditLog`):

| Column | Type | Note |
|--------|------|------|
| `log_id` | BIGSERIAL PK | high-volume sequential inserts |
| `user_id` | UUID FK (`SET NULL`) | who (nullable) |
| `user_email`, `user_role` | string | **denormalized** so logs stay readable if the user is deleted |
| `action` | string(100) | what happened |
| `resource_type` | string(50) | `AuditResourceType` — **CamelCase** (RFC-PROTOCOL §1) |
| `resource_id` | UUID | which entity |
| `ip_address` | INET · `user_agent` Text · `request_id` UUID | context |
| `changes` | JSONB | `{ "before": {…}, "after": {…} }` |
| `success` | bool (default true) · `error_message` Text | outcome |
| `timestamp` | timestamp (default now) | when |

Action-body fields with no own column (approve/cancel/dispute notes & reasons — RFC-PROTOCOL §3.6) are captured
here in `changes`. Audit-log **read access** is restricted (RFC-PROTOCOL §2.3: Auditor ⚠️ limited, Sys Admin ✅).

## 4. Managed object: health & readiness `[MVP]`

| Probe | Returns | Use |
|-------|---------|-----|
| `GET /api/v1/health` | `{ status:"ok", service, environment }` | **liveness** — is the process up? (LB / uptime checks) |
| `GET /api/v1/health/ready` | `{ status:"ok"\|"degraded", database:"up"\|"down" }` | **readiness** — can it reach Postgres now? |

Both are unauthenticated.

## 5. Managed object: rate-limit counters `[MVP]`

The gateway (G2) applies **per-(path-class, client-IP)** fixed-window limits. The client IP comes from
`X-Forwarded-For`/`X-Real-IP` (set by NGINX in prod), else `"unknown"` (one shared bucket).

| Path class | Limit | Window | Post-breach block |
|------------|------:|-------:|------------------:|
| `/api/v1/auth/login` | 5 | 900 s | 1800 s |
| `/api/v1/auth/register` | 3 | 3600 s | 7200 s |
| `/api/v1/auth/*` (other) | 10 | 900 s | 1800 s |
| `/api/v1/*` (general) | 60 | 60 s | 300 s |
| everything else (static) | 1000 | 60 s | none |

Allowed responses carry `X-RateLimit-Limit` + `X-RateLimit-Remaining`; a breach returns **429** with
`{ detail, code:"RATE_LIMITED", retry_after }` + `Retry-After`. **Storage is pluggable:** `InMemoryStore`
(single-instance MVP default, zero deps) or `RedisStore` (shared across replicas for scale `[MVP→FFP]`), which
**fails open** — a Redis outage allows the request rather than locking users out.

## 6. Managed object: cache keys & TTLs `[MVP]`

| Key pattern | Purpose | TTL |
|-------------|---------|-----|
| `analytics:dashboard` | dashboard metrics cache | 300 s |
| `ratelimit:{path}:{ip}` | fixed-window counter | window seconds |
| `ratelimit:block:{path}:{ip}` | post-breach cooldown flag | block seconds |

All cache/counter access is best-effort and degrades gracefully on a Redis outage (cache recomputes; limiter
fails open). Broader Redis key conventions live in `IDRM-Redis-Operations.md`.

## 7. SLOs / targets `[MVP→FFP]` (decision D11)

| Objective | MVP target | Scale target |
|-----------|-----------|--------------|
| API latency (p95, per category) | < 500 ms | < 500 ms |
| Page load | < 3 s | < 3 s |
| DB query | < 100 ms | < 100 ms |
| User satisfaction (1–5) | ≥ 4.0 | ≥ 4.5 |
| Uptime | 99.5 % | 99.9 % |

## 8. What is NOT yet observable (gaps) `[MVP]`

- **No metrics endpoint / Prometheus exporter is implemented.** The Monitoring Guide describes a
  Prometheus+Grafana stack, but no `/metrics` exporter exists in `src/` yet — SLO measurement is currently
  manual/external. Logged **C-MGMT-1**.
- **No request-tracing/`request_id` propagation** is wired through the gateway→backend path (the audit column
  exists but is not populated end-to-end). Logged **C-MGMT-2**.
- These are `[MVP→FFP]` observability build-outs.

## Appendix Z. Changes & open items

- **C-MGMT-1** (no Prometheus exporter built), **C-MGMT-2** (request_id not propagated) — logged in RFC-CLARIFY.
- The dashboard object mirrors CLAUDE.md §Analytics; audit reads are gated by RFC-PROTOCOL §2.3.
