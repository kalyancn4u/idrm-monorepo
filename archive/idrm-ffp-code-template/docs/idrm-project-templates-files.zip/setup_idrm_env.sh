#!/usr/bin/env bash
# ==================================================================
# setup_idrm_env.sh
# Provisions the `idrm-backend` conda environment for the IDRM
# Python/FastAPI/PostGIS/DSML backend, on a fresh or existing
# Ubuntu machine (matches the PRD's standalone-box deployment model).
#
# What it does, in order:
#   1. Installs Miniforge (conda + mamba, conda-forge by default)
#      ONLY if neither conda nor mamba is already on PATH.
#   2. Pins the conda-forge channel with strict priority — required
#      for the GDAL/GEOS/PROJ geospatial stack to resolve cleanly.
#   3. Creates the env from environment.yml (or updates it in place
#      if it already exists — safe to re-run after editing the yml).
#   4. Sanity-checks that every key package actually imports.
#
# Usage:
#   chmod +x setup_idrm_env.sh
#   ./setup_idrm_env.sh
#
# Requires: environment.yml in the same directory as this script.
# Validated commands: github.com/conda-forge/miniforge (June 2026).
# ==================================================================
set -euo pipefail

ENV_NAME="idrm-backend"
ENV_FILE="$(dirname "$0")/environment.yml"
MINIFORGE_DIR="${HOME}/miniforge3"

log()  { printf '\n\033[1;36m==> %s\033[0m\n' "$1"; }
fail() { printf '\033[1;31mERROR: %s\033[0m\n' "$1" >&2; exit 1; }

# ------------------------------------------------------------------
# 1. Bootstrap Miniforge if conda/mamba isn't already available
# ------------------------------------------------------------------
if command -v mamba &>/dev/null; then
    CONDA_BIN="mamba"
elif command -v conda &>/dev/null; then
    CONDA_BIN="conda"
else
    log "conda/mamba not found — installing Miniforge into ${MINIFORGE_DIR}"
    INSTALLER="Miniforge3-$(uname)-$(uname -m).sh"
    curl -L -O "https://github.com/conda-forge/miniforge/releases/latest/download/${INSTALLER}"
    bash "${INSTALLER}" -b -p "${MINIFORGE_DIR}"
    rm -f "${INSTALLER}"

    # Make conda available in THIS shell session without a re-login
    source "${MINIFORGE_DIR}/etc/profile.d/conda.sh"
    source "${MINIFORGE_DIR}/etc/profile.d/mamba.sh" 2>/dev/null || true

    # Persist conda/mamba on PATH for future shells
    "${MINIFORGE_DIR}/bin/conda" init bash
    log "Miniforge installed. Open a new shell later to get conda by default."
    CONDA_BIN="conda"
fi
log "Using package manager: ${CONDA_BIN}"

# ------------------------------------------------------------------
# 2. Verify environment.yml is present
# ------------------------------------------------------------------
[[ -f "${ENV_FILE}" ]] || fail "environment.yml not found at ${ENV_FILE}"

# ------------------------------------------------------------------
# 3. Channel config — conda-forge only, strict priority
#    (mixing 'defaults' + conda-forge is the #1 cause of GDAL/PROJ
#    import errors on the geospatial stack)
# ------------------------------------------------------------------
log "Configuring conda-forge channel with strict priority"
conda config --add channels conda-forge
conda config --set channel_priority strict

# ------------------------------------------------------------------
# 4. Create or update the environment
# ------------------------------------------------------------------
if conda env list | awk '{print $1}' | grep -qx "${ENV_NAME}"; then
    log "Environment '${ENV_NAME}' exists — updating from ${ENV_FILE}"
    "${CONDA_BIN}" env update -n "${ENV_NAME}" -f "${ENV_FILE}" --prune
else
    log "Creating environment '${ENV_NAME}' from ${ENV_FILE}"
    "${CONDA_BIN}" env create -f "${ENV_FILE}"
fi

# ------------------------------------------------------------------
# 5. Sanity-check that key packages actually import
# ------------------------------------------------------------------
log "Running import sanity check inside '${ENV_NAME}'"
conda run -n "${ENV_NAME}" python - <<'PYEOF'
import importlib

# import-name != pypi/conda-name for a few of these — mapped correctly
packages = [
    "fastapi", "uvicorn", "pydantic", "pydantic_settings",
    "sqlalchemy", "alembic", "psycopg2", "asyncpg", "geoalchemy2",
    "redis", "celery", "twilio",
    "osgeo.gdal", "geopandas", "shapely", "pyproj", "fiona", "rasterio",
    "pandas", "numpy", "scipy", "sklearn", "matplotlib", "plotly",
    "jinja2", "weasyprint", "reportlab", "openpyxl", "xlsxwriter",
    "pytest", "httpx", "faker",
    "razorpay", "stripe", "sendgrid", "pyfcm", "socketio",
]

failed = []
for pkg in packages:
    try:
        importlib.import_module(pkg)
    except Exception as e:
        failed.append((pkg, f"{type(e).__name__}: {e}"))

if failed:
    print(f"\n{len(failed)} package(s) failed to import:")
    for pkg, err in failed:
        print(f"  - {pkg}: {err}")
    raise SystemExit(1)

print(f"\nAll {len(packages)} key packages imported successfully.")
PYEOF

# ------------------------------------------------------------------
# 6. Done
# ------------------------------------------------------------------
log "Setup complete."
echo "Activate the environment with:"
echo "    conda activate ${ENV_NAME}"
