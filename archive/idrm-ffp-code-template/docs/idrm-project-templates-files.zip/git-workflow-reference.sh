#!/usr/bin/env bash
# ==================================================================
# git-workflow-reference.sh
# Every command from your raw history, reordered into the logical
# sequence a real git lifecycle actually follows — nothing removed,
# nothing added. Each cluster has a rationale comment explaining WHY
# it sits where it does.
#
# THIS IS A REFERENCE / CHEAT-SHEET, NOT A SCRIPT TO RUN TOP-TO-BOTTOM:
#   - the -h / --help lines are interactive lookups, not actions
#   - `vim README-git.txt` will open an editor and block
#   - `git reset --hard origin/main` is DESTRUCTIVE (discards local
#     uncommitted changes) — only run it when that's truly the intent
# Pattern you were already following, made explicit: for almost every
# verb you look up `-h` then `--help` BEFORE running it for real. That's
# good practice — kept as the organizing principle throughout.
# ==================================================================


# ==================================================================
# PHASE 0 — Personal shell aliases (context only, not git commands)
# Rationale: these aren't git at all — they're your own shell
# shortcuts (ff, gs, cdcode, cdgitr). Kept here, commented, as the
# "muscle memory" entry point into the workflow below — presumably
# gs ≈ git status, cdcode/cdgitr ≈ jump to your code/repo dirs.
# ==================================================================
# ff
# gs
# cdcode
# cdgitr


# ==================================================================
# PHASE 1 — One-time global identity config
# Rationale: user.name/user.email are GLOBAL (apply to every repo on
# this machine), so this only ever needs doing once per machine, and
# logically comes before you ever touch a repo. Check existing state
# first (--list / ~/.gitconfig) before overwriting it.
# ==================================================================
git config -h
git config --help
git config --global --list                 # see what's already set
# cat ~/.gitconfig                          # raw-file alternative view
git config --global user.name "kalyan.narayana"
git config --global user.email "kalyancn4u@gmail.com"


# ==================================================================
# PHASE 2 — Initialize the repository
# Rationale: nothing else is possible until the repo exists.
# ==================================================================
git init -h
git init --help
git init


# ==================================================================
# PHASE 3 — First commit: status -> add -> commit -> status
# Rationale: this is the canonical three-step loop (see what changed,
# stage it, commit it) — bookended by `status` so you both start and
# end with a known, verified state of the working tree.
# ==================================================================
git status -h
git status --help
git status                                  # expect: "no commits yet"

git add -h
git add --help
git add .

git commit -h
git commit --help
git commit -m "Initial commit"

git status                                  # confirm clean tree post-commit


# ==================================================================
# PHASE 4 — Verify what's tracked vs. untracked (ls-files)
# Rationale: immediately after the first commit is the natural point
# to confirm git is tracking what you THINK it's tracking, before you
# go any further (branches, remotes, etc.) on top of it.
# Ordered simplest -> most filtered.
# ==================================================================
git ls-files -h
git ls-files --help
git ls-files                                # bare = tracked/cached files
git ls-files --others                       # untracked, including ignored
git ls-files --others --exclude-standard    # untracked, ignored files excluded
# NOTE: as typed below, "-cached" is a single dash, so git parses it as
# bundled short flags (-c -a -c -h -e -d), not the long flag --cached —
# this is very likely why this one didn't behave as expected. Kept
# verbatim since it's what you actually ran; corrected form shows up
# in Phase 7 below where you got the flag right.
git ls-files --others --exclude-standard -cached


# ==================================================================
# PHASE 5 — Get oriented: branches (still pre-remote)
# Rationale: before wiring up GitHub, it's worth knowing what
# branch(es) you actually have locally. `-M main` at the end renames
# the default branch to "main" — the logical prerequisite immediately
# before pushing to a GitHub repo whose default branch is "main".
# ==================================================================
git branch -h
git branch --help
git branch
git branch -v
git branch -vv
git branch -a
git branch -r
git branch -M main


# ==================================================================
# PHASE 6 — SSH key generation & GitHub auth check
# Rationale: logically belongs right before connecting to a remote —
# no point generating a key you're not about to use for the push.
# ==================================================================
ssh-keygen -t rsa -b 4096 -C "kalyancn4u@gmail.com"
cat ~/.ssh/id_rsa.pub                       # copy this into GitHub > SSH keys
ssh -T git@github.com                       # confirms GitHub recognizes the key
# git remote set-url origin git@github.com:kalyancn4u/mlops-bgn-docker-flask-app.git
# ^ commented = noted as the fallback if you decide to switch the
#   remote from HTTPS to SSH; left un-run here, so the push below is
#   presumably still going over HTTPS (with a PAT or credential helper)


# ==================================================================
# PHASE 7 — Wire up the remote & push for the first time
# Rationale: this is the actual "go live on GitHub" moment — comes
# after identity, first commit, branch rename, and auth are all in
# place. `-u` on the second push sets the upstream tracking branch,
# which is what lets a bare `git push`/`git pull` work later without
# specifying remote+branch every time.
# ==================================================================
# git remote add origin https://github.com/kalyancn4u/mlops-bgn-docker-flask-app.git
git push origin main                        # first push attempt (no upstream link yet)

git ls-files --others --exclude-standard --cached  # corrected flag — sanity-check
git ls-files                                        # tracked files, post-push

git push -u origin main                     # now link local main -> origin/main


# ==================================================================
# PHASE 8 — Deep history & diff inspection (local vs. remote)
# Rationale: once there's a remote to compare against, this whole
# family of log/rev-list/diff variants becomes meaningful — comparing
# HEAD...origin/main only makes sense once origin actually exists.
# Grouped here as one "how do I read history" exploration pass.
# ==================================================================
git log --all --format="%H"                 # first commit-hash sweep, post-push
git log --oneline --graph --left-right HEAD...origin/main  # first ahead/behind graph check

# --- mid-cycle: a real edit + commit happened here in your history ---
# git commit -a                             # noted alternative: stage tracked
                                             # changes + commit in one step
git add .
git commit -m "Updated README-git.txt with git compare usage"

git log --help
git log
git log --reverse
git log --oneline
git log --oneline -n 1
git log --oneline --all
git log --oneline --reverse
git log --oneline --all --reverse
git log --oneline origin/main --reverse
git log --oneline --reverse -n 1
git log --all --format="%H"                 # re-run after the new commit
git log --all --format="%H %an %ad"         # extended: author + date
git log --oneline --graph --left-right HEAD...origin/main  # ahead/behind, visually

git rev-list --help
git rev-list --left-right --count HEAD...origin/main       # ahead/behind, as numbers

git diff --help
git diff .
git diff --cached origin/main


# ==================================================================
# PHASE 9 — General-purpose investigation utilities (non-git)
# Rationale: plain OS/shell tools you'd reach for alongside the git
# commands above — not git operations themselves, just supporting
# checks (what files actually exist on disk, what did I already run).
# ==================================================================
find .
history | egrep commit


# ==================================================================
# PHASE 10 — Remote-sync mechanics: fetch / pull / merge / reset
# (your own "### TODO" marker — kept as the header for the cluster
# you'd flagged as needing more practice)
# Rationale: logically this is its own phase — distinct from "reading
# history" (Phase 8) and from "making a new commit" (Phase 3/13).
# This is specifically about reconciling local with what's now on
# the remote.
# ==================================================================
### TODO — fetch vs. pull vs. merge vs. reset --hard, in practice

git remote show origin                      # what's the remote tracking now
git fetch                                   # pull down refs, don't merge yet
git pull                                    # fetch + merge in one step
git rev-parse --abbrev-ref HEAD             # which branch am I actually on

# NOTE: "-all" (single dash) — git parses this as bundled short flags,
# not the long --all. Intended form is `git fetch --all`. Kept as run.
git fetch -all

# DESTRUCTIVE: discards any local uncommitted changes/commits not on
# origin/main, forcing local to exactly match the remote. Only ever
# run this when that's genuinely what you want.
git reset --hard origin/main

git merge                                   # merges from the tracked upstream
                                             # (works because `-u` was set in Phase 7)

# NOTE: "-oneline" (single dash) — intended --oneline. Kept as run.
git log --all -oneline

git fetch --all                             # correct form, re-run properly
git log --all --oneline                     # correct form, re-check history


# ==================================================================
# PHASE 11 — Authorship inspection (blame)
# Rationale: a distinct investigative tool from log/diff — "who
# changed this line and when" rather than "what changed overall".
# Natural next step once history/sync state is understood.
# ==================================================================
git blame
git blame .
git blame README-git.txt


# ==================================================================
# PHASE 12 — Post-sync diff check, before the next edit
# Rationale: after fetch/pull/merge/reset above, the natural question
# is "what does my working tree look like now, relative to before?"
# ==================================================================
git diff
git diff -a                                 # force text-mode diff (binary-safe)
git log --oneline --all                     # re-confirm history one more time


# ==================================================================
# PHASE 13 — Next edit/commit/push cycle, plus final remote checks
# Rationale: the same status->commit->push shape as Phase 3, now with
# a fuller set of pre-push comparisons against origin/main, since by
# this point you have more git vocabulary to verify with before
# trusting the push.
# ==================================================================
git commit -h
git commit -m "Updated usage sample changes"

git diff -h
git diff
git diff --cached
git diff origin/main
git diff main origin/main                   # explicit two-ref form of the above

git rev-parse --show-toplevel                # confirm repo root (useful with cdcode/cdgitr)
git remote -v                                # confirm remote URL(s) — http vs ssh

# git push -u origin main                    # safety-net reminder; -u already
                                              # set back in Phase 7, so plain push works
git push
git status                                   # final clean-tree confirmation


# ==================================================================
# ITERATION 2 — the same edit/review/sync/commit/push cycle, run
# again on a later date. This whole section mirrors Phases 8/10/11/13
# above almost line-for-line — kept in full because that's literally
# what you ran a second time, not collapsed into "see above".
# ==================================================================

# --- pre-edit check: has origin moved since I last looked? ---------
git rev-list --left-right --count HEAD...origin/main
find .
git log --reverse

# --- the actual edit ------------------------------------------------
vim README-git.txt

# --- review before committing ---------------------------------------
git diff --cached origin/main
# NOTE: no explicit `git add` appears in your history between the vim
# edit and this commit. Either README-git.txt was already staged from
# an earlier step, or this relied on something outside this captured
# history. Worth adding `git add README-git.txt` here for a clean,
# reproducible record.
git commit -m "Updated README-git.txt with compare diff commands"
git diff --cached origin/main               # re-check: new commit vs. origin/main

# --- sync workflow, second pass (your "# TODO" marker again) -------
# TODO — same fetch/pull/merge/reset cluster, second practice pass
git fetch
git pull
git log --oneline origin/main
git rev-parse --abbrev-ref HEAD
git fetch -all                              # same typo as before, kept as run
git reset --hard origin/main                # DESTRUCTIVE — see Phase 10 note
git log
git log --oneline
git merge
git log --all -oneline                      # same typo as before, kept as run
git fetch --all
git log --all --oneline

# --- authorship check, second pass ----------------------------------
git blame
git blame .
git blame README-git.txt

# --- final diff/push checks, second pass ----------------------------
git diff
git diff --ca                               # valid: unambiguous abbreviation
                                             # of --cached (git allows prefix
                                             # matching of long options)
git log --oneline --all
git diff origin/main
git rev-parse --show-toplevel
git remote -v
git diff
git diff --cached
git push
git diff main origin/main                   # post-push: should now show no diff
git remote show origin                      # final overview of remote tracking state
