-- =================================================================
-- infra/postgres/init.sql
-- IDRM — PostgreSQL extension initialization
-- =================================================================
-- Mounted at: /docker-entrypoint-initdb.d/10-init.sql
-- Runs ONCE on first container start against an empty data directory.
-- Safe to leave mounted; ignored on subsequent starts with existing data.
--
-- postgis + postgis_topology: already auto-installed by the
--   postgis/postgis:16-3.4 image, but listed here explicitly
--   so the extensions are documented and the script is idempotent.
-- =================================================================

-- Spatial extensions (core IDRM requirement)
CREATE EXTENSION IF NOT EXISTS postgis;
CREATE EXTENSION IF NOT EXISTS postgis_topology;

-- Text search (incident description search, location name fuzzy match)
CREATE EXTENSION IF NOT EXISTS pg_trgm;

-- UUIDs for PKs (incident_id, request_id, donor_id etc.)
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Crypto for tokens inside the DB (password hashing fallback, HMAC)
CREATE EXTENSION IF NOT EXISTS pgcrypto;

-- Verify installation
SELECT
    name,
    default_version,
    installed_version
FROM pg_available_extensions
WHERE name IN (
    'postgis',
    'postgis_topology',
    'pg_trgm',
    'uuid-ossp',
    'pgcrypto'
)
ORDER BY name;
